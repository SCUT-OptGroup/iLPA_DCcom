Please run the following steps in the Matlab command window:

1.  Run Matlab in the directory iLPA_DCcom

2. a) To generate Figure 1 in the paper, perform:

      >> test_lambda_iLPA and test_lambda_subgrad;

   b) To generate Figure 2 in the paper, perform:

      >> test_noisesparse and test_time_iPMM ;

  c) To generate Table 1 in the paper, perform:

      >> test_Synthetic with different noise and different c_lambda.
