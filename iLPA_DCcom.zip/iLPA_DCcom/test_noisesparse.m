%%************************************************************************
%% run random matrix completion problems. 
%% ************************************************************************

%% ****************************************************************************
clear all;

restoredefaultpath;

addpath(genpath('SCAD_DC'));

addpath(genpath('get_noise'));

addpath(genpath('PROPACKmod'));
%%

OPTIONS_iPMM.maxiter = 2000;

OPTIONS_iPMM.printyes = 1;

OPTIONS_iPMM.tol = 5.0e-6;

%% generate random a test problem

scenario = 'noisy';

sample_type ='nonuniform';

ntest = 10;        % number of testing

acon = 4;

pars.acon = acon;

%% ************** Initialization for test problem ******************

nr = 1000;     nc = 1000;     

rstar = 5;     SR = 0.25;

nsp_list =  [0.1:0.05:1] %0.8% [ 0.10   0.14   0.18  0.2   0.24   0.28     0.3      0.34   0.38    0.4     0.44     0.48   0.5   0.6    0.7   0.8 ];

ns = length(nsp_list);

%% ***************** Initialization *********************************

scadPAM_matrelerr = zeros(ntest,ns);

scadPAM_matrank = zeros(ntest,ns);  
 
scadPAM_mattime = zeros(ntest,ns);   

%% ******************** main loop  **********************************************

for i = 1:ns
    
    i
    
    nsp = nsp_list(i);
  
    for test_iter = 1:ntest
        
        test_iter
        
        randstate =  100*i*test_iter  
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        if strcmp(scenario,'noiseless')
            noiseratio = 0;
        else
            noiseratio = 0.1;
        end
        
        fprintf('\n nr = %2.0d,   nc = %2.0d,   rank = %2.0d\n,',nr,nc,rstar);
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        p = round(SR*nr*nc);     %% number of sampled entries
       
       %% *************** to generate the true matrix ******************
        
        M.U = randn(nr,rstar);
        
        M.V = randn(nc,rstar);
 
        normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
    
        Mstar = M.U*M.V';
        
        num_sample = p;
        
       %%  ***********  uniform sampling  ***************************
        
        if strcmp(sample_type,'uniform')
            
            fprintf('\n *********** uniform sampling ***************\n \n');
           
            fprintf('\n SR = %2.2f��  noiseratio = %2.2f\n,',SR,noiseratio);
            
            idx = randperm(nr*nc);
            
            nzidx = idx(1:p)';
            
            zidx = idx(p+1:end)';
        
        elseif strcmp(sample_type,'nonuniform')
        
       %%  *************  non-uniform sampling  ********************** 
            fprintf('\n non-uniform sampling\n');
            fprintf('\n SR = %2.2f��  noiseratio = %2.2f\n,',SR,noiseratio);
            pvec = ones(nr,1);
            cnt = round(0.1*nr);
            pvec(1:cnt) = 2*pvec(1:cnt);
            pvec(cnt+[1:cnt]) = 4*pvec(cnt+[1:cnt]);
            pvec = nr*pvec/sum(pvec);
            qvec = ones(nc,1);
            cnt = round(0.1*nc);
            qvec(1:cnt) = 2*qvec(1:cnt);
            qvec(cnt+[1:cnt]) = 4*qvec(cnt+[1:cnt]);
            qvec = nc*qvec/sum(qvec);
            probmatrix = rand(nr,nc).*(pvec*qvec');
            [probvec,sortidx] = sort(probmatrix(:),'descend');
            nzsortidx = find(probvec>= probvec(p));
            nzidx = sortidx(nzsortidx);
            zidx = sortidx(p+1:end);
        end
        
        bb =  Mstar(nzidx);
        
        if strcmp(scenario,'noiseless')
            xi = sparse(p,1);
            sigma = 0;
        else 
          %% errtype = 0,   Non-sparse Gaussian noise         
          %% errtype = 1-5, Sparse heavy tail noise
            
          errtype = 5 %% 1-5
          
          xi = get_noise_sp(p,nsp,bb,errtype,randstate);
     
        end
         
        bb = bb + xi;
        
        A = zeros(nr,nc);
        
        A(nzidx) = bb;
              
     %% ***************** Initialization part ************************
        
        normb = norm(bb);
        
        r = min(round(min(nr,nc)/2),100);
        
        pars.normM = normM;
        
        pars.normb = normb;
        
        pars.nc = nc;  pars.nr = nr;   pars.ns = p;   pars.r = r;
        
      %% ********************** to seek the starting point ******************************   
    
        [U,dA,V] = svd(full(A),'econ');
        
        Ustart = U(:,1:r);
        
        Vstart = V(:,1:r);
        
        dA = diag(dA)';
        
        max_dA = max(dA);
            
        Ustart_AMM = Ustart.*dA(1:r).^(1/2);
         
        Vstart_AMM = Vstart.*dA(1:r).^(1/2); 
        
        Xstart = Ustart_AMM*Vstart_AMM';
       
        Xs = Xstart(nzidx); 
            
     %% **************** iPMM_scadLoss for solving scad loss problem ***********************************************
 
        lambda = 0.06*normb   
        
        rho = 1.0e-2;    
        
        pars.rho = rho;
        
        tstart = clock; 
      
        [Xopt,rankX] = iPMM_scad(Ustart,Vstart,Xs,bb,normb,nzidx,OPTIONS_iPMM,pars,lambda,normM,Mstar);
        
        scadPAM_time = etime(clock,tstart);
        
        scadPAM_relerr = norm(Xopt- Mstar,'fro')/normM
        
        scadPAM_matrank(test_iter,i) = rankX
        
        scadPAM_matrelerr(test_iter,i) = scadPAM_relerr
        
        scadPAM_mattime(test_iter,i) =  scadPAM_time
        
         
    end
        
    iPMM_averelerr(i)= mean(scadPAM_matrelerr(:,i))
    
    iPMM_averank(i)= mean(scadPAM_matrank(:,i))
    
    iPMM_avetime(i)= mean(scadPAM_mattime(:,i))
    
end
  
save('iPMM_result','iPMM_averelerr','iPMM_averank','iPMM_avetime')

%% *************************************************************************
