%%************************************************************************
%% run random matrix completion problems.
%% ************************************************************************
clear all;

restoredefaultpath;

addpath(genpath('Subgrad_scadLoss'));

addpath(genpath('get_noise'));


%%

OPTIONS_Subgrad.maxiter = 2000;

OPTIONS_Subgrad.printyes = 1;

OPTIONS_Subgrad.tol = 5.0e-6;

%% generate random a test problem

scenario = 'noisy';

sample_type ='nonuniform';

ntest = 10;

acon = 4;

pars.acon = acon;

%% ************** Initialization for test problem ******************

nr = 1000;   nc = 1000;

rstar = 5;   SR = 0.25;

list_clambda =  [0.005   0.01   0.015    0.02     0.03    0.04    0.05    0.06    0.07    0.08     0.09   0.1  0.12  0.14]

len = length(list_clambda)

%% ***************** Initialization *********************************

Subgrad_matrelerr = zeros(ntest,len);

Subgrad_matrank = zeros(ntest,len);  
 
Subgrad_mattime = zeros(ntest,len);   

%% ***********************************************************************

for i = 1:len
    
    i    
    clambda = list_clambda(i)
    
    for test_iter = 1:ntest
        
        test_iter
        
        randstate =  100*i*test_iter
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        
        if strcmp(scenario,'noiseless')
            noiseratio = 0;
        else
            noiseratio = 0.1;
        end
        
        fprintf('\n nr = %2.0d,   nc = %2.0d,   rank = %2.0d\n,',nr,nc,rstar);
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        p = round(SR*nr*nc);     %% number of sampled entries
        
        %% *************** to generate the true matrix ******************
        
        M.U = randn(nr,rstar);
        
        M.V = randn(nc,rstar);
        
        normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
        
        Mstar = M.U*M.V';
        
        num_sample = p;
        
        %%  ***********  uniform sampling  ***************************
        
        if strcmp(sample_type,'uniform')
            
            fprintf('\n *********** uniform sampling ***************\n \n');
            
            fprintf('\n SR = %2.2f\n?  noiseratio = %2.2f\n,',SR,noiseratio);
            
            idx = randperm(nr*nc);
            
            nzidx = idx(1:p)';
            
            zidx = idx(p+1:end)';
            
        elseif strcmp(sample_type,'nonuniform')
            
            %%  *************  non-uniform sampling  **********************
            fprintf('\n non-uniform sampling\n');
            fprintf('\n SR = %2.2f,  noiseratio = %2.2f\n,',SR,noiseratio);
            pvec = ones(nr,1);
            cnt = round(0.1*nr);
            pvec(1:cnt) = 2*pvec(1:cnt);
            pvec(cnt+[1:cnt]) = 4*pvec(cnt+[1:cnt]);
            pvec = nr*pvec/sum(pvec);
            qvec = ones(nc,1);
            cnt = round(0.1*nc);
            qvec(1:cnt) = 2*qvec(1:cnt);
            qvec(cnt+[1:cnt]) = 4*qvec(cnt+[1:cnt]);
            qvec = nc*qvec/sum(qvec);
            probmatrix = rand(nr,nc).*(pvec*qvec');
            [probvec,sortidx] = sort(probmatrix(:),'descend');
            nzsortidx = find(probvec>= probvec(p));
            nzidx = sortidx(nzsortidx);
            zidx = sortidx(p+1:end);
        end
        
        bb =  Mstar(nzidx);
        
        if strcmp(scenario,'noiseless')
            xi = sparse(p,1);
            sigma = 0;
        else
            %% errtype = 0,   Non-sparse Gaussian noise
            %% errtype = 1-5, Sparse heavy tail noise
            
            errtype = 5  %% 1-5
            
            xi = get_noise(p,bb,errtype,randstate);
            
        end
        
        bb = bb + xi;
        
        A = zeros(nr,nc);
        
        A(nzidx) = bb;
        
        %% *************** Initialization part *********************
        
        r = min(round(min(nr,nc)/2),100);
        
        pars.normM = normM;  normb = norm(bb);
        
        pars.normb = normb;
        
        pars.nc = nc;  pars.nr = nr;   pars.ns = p;    pars.r = r;
        
        %% ********************** to seek the starting point ******************************
        
        [U,dA,V] = svd(full(A),'econ');
        
        Ustart = U(:,1:r);
        
        Vstart = V(:,1:r);
        
        dA = diag(dA)';
        
        Ustart_AMM = Ustart.*dA(1:r).^(1/2);
        
        Vstart_AMM = Vstart.*dA(1:r).^(1/2);
        
        Xstart = Ustart_AMM*Vstart_AMM';
        
        Xs = Xstart(nzidx);
        
        clear U  V  dA;
        
 %%        
        tstart = clock;
        
        lambda = clambda*normb;
        
        [Xopt] = Subgrad_scadLoss(Ustart,Vstart,nzidx,bb,normb,OPTIONS_Subgrad,pars,lambda);

         Xsv = svds(Xopt,r); rankX = sum(Xsv>1.0e-4*max(Xsv));
        
        subgrand_time = etime(clock,tstart);
        
        subgrand_relerr = norm(Xopt-Mstar,'fro')/normM
        
        subgrand_matrank(test_iter,i) = rankX
        
        subgrand_matrelerr(test_iter,i) = subgrand_relerr
        
        subgrand_mattime(test_iter,i) =  subgrand_time
    end
        
    subgrand_averelerr(i)= mean(subgrand_matrelerr(:,i))
    
    subgrand_averank(i)= mean(subgrand_matrank(:,i))
    
    subgrand_avetime(i)= mean(subgrand_mattime(:,i))
    
end

save('subgrad_result','subgrand_averelerr','subgrand_averank','subgrand_avetime')

%% *************************************************************************