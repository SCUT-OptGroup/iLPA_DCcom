%% ************************************************************************
%% run random matrix completion problems. 
%% ************************************************************************

clear all;

restoredefaultpath;

addpath(genpath('SCAD_DC'));

addpath(genpath('get_noise'));

addpath(genpath('PROPACKmod'));

addpath(genpath('Subgrad_scadLoss'));

%%

OPTIONS_iPMM.maxiter = 2000;

OPTIONS_iPMM.printyes = 1;

OPTIONS_iPMM.tol = 5.0e-6;

OPTIONS_Subgrad.maxiter = 2000;

OPTIONS_Subgrad.printyes = 1;

OPTIONS_Subgrad.tol = 5.0e-6;

%% generate random a test problem

scenario = 'noisy'; % noisy  noiseless

ntest = 10;

acon = 4;

pars.acon = acon;

%% ************** Initialization for test problem ******************

nr = 3000;  nc = 3000;  % nr=3000,  nr=5000

rstar = 15;  %15 

SR = [0.15  0.2  0.25]; 

ns = length(SR);

%% errtype = 0       Non-sparse Gaussian noise         
%% errtype = 1-5     Sparse heavily-tailed noise
            
 errtype = 1 %% 1-5

%% ***************** Initialization *********************************

iPMM_matrelerr = zeros(ntest,ns); SubgScad_matrelerr = zeros(ntest,ns);  

iPMM_matrank = zeros(ntest,ns);   SubgScad_matrank = zeros(ntest,ns);    

iPMM_mattime = zeros(ntest,ns);   SubgScad_mattime = zeros(ntest,ns);   

%% ******************** main loop  **********************************************

for i = 1:ns

    for test_iter = 1:ntest
        
        test_iter
        
        randstate =  100*i*test_iter
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        fprintf('\n nr = %2.0d,   nc = %2.0d,   rank = %2.0d\n',nr,nc,rstar);
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        p = round(SR(i)*nr*nc);     %% number of sampled entries
        
        pars.p = p;
        
       %% *************** to generate the true matrix ******************
        
        M.U = randn(nr,rstar);
        
        M.V = randn(nc,rstar);
        
        normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
        
        Mstar = M.U*M.V';
        
        num_sample = p;
        
    %%  *************  non-uniform sampling  **********************
        fprintf('\n non-uniform sampling\n');
        fprintf('\n SR = %2.2f,',SR(i));
        pvec = ones(nr,1);
        cnt = round(0.1*nr);
        pvec(1:cnt) = 2*pvec(1:cnt);
        pvec(cnt+[1:cnt]) = 4*pvec(cnt+[1:cnt]);
        pvec = nr*pvec/sum(pvec);
        qvec = ones(nc,1);
        cnt = round(0.1*nc);
        qvec(1:cnt) = 2*qvec(1:cnt);
        qvec(cnt+[1:cnt]) = 4*qvec(cnt+[1:cnt]);
        qvec = nc*qvec/sum(qvec);
        probmatrix = rand(nr,nc).*(pvec*qvec');
        [probvec,sortidx] = sort(probmatrix(:),'descend');
        nzsortidx = find(probvec>= probvec(p));
        nzidx = sortidx(nzsortidx);
        zidx = sortidx(p+1:end);
             
        bb =  Mstar(nzidx);
        
        if strcmp(scenario,'noiseless')
            xi = sparse(p,1);
            sigma = 0;
        else 
          
          xi = get_noise(p,bb,errtype,randstate);
         
        end
        
        bb = bb + xi;    
        
        A = zeros(nr,nc);
        
        A(nzidx) = bb;
        
     %% ***************** Initialization part ************************
        
        normb = norm(bb);
        
        r = min(round(min(nr,nc)/2),100);
        
        pars.nc = nc;  pars.nr = nr;   
        
        pars.ns = p;   pars.r = r;
        
%% ********************** to seek the starting point **************** 
        tstart = clock; 

        options = 1.0e-6;

        [U,dA,V] = lansvd(A,r,'L',options); %svd(A,'econ'); %

        dAvec = diag(dA)';

        Ustart = U(:,1:r);  Vstart = V(:,1:r);

        Ustart = Ustart.*dAvec(1:r).^(1/2);

        Vstart = Vstart.*dAvec(1:r).^(1/2);

        time1 = etime(clock,tstart);
        
 %% **************** iPMM_scadLoss for solving scad loss problem ***********************************************
       
        lambda = 0.06*normb    % 0.1   0.03     % 0.015*normb: 0.015-0.03 for err3 sr=0.15; 0.01-0.03 for err3 sr=0.2$       
            
        tstart = clock;

        Xstart = Ustart*Vstart';

        Xs = Xstart(nzidx);

        [Xopt,rankX] = iPMM_scad(Ustart,Vstart,Xs,bb,normb,nzidx,OPTIONS_iPMM,pars,lambda,normM,Mstar);
       
        scadPAM_time = etime(clock,tstart) + time1;
        
        scadPAM_relerr = norm(Xopt- Mstar,'fro')/normM
        
        scadPAM_matrank(test_iter,i) = rankX
        
        scadPAM_matrelerr(test_iter,i) = scadPAM_relerr
        
        scadPAM_mattime(test_iter,i) = scadPAM_time

    %% ****************  Subgradient for solving SCAD loss problem ***************************

        lambda = 0.06*normb     
        
        tstart = clock; 
     
        [Xopt] = Subgrad_scadLoss(Ustart,Vstart,nzidx,bb,normb,OPTIONS_Subgrad,pars,lambda);

        Xsv = svds(Xopt,r); rankX = sum(Xsv>1.0e-4*max(Xsv));
       
        SubgScad_time = etime(clock,tstart) + time1;
        
        Subgrad_relerr = norm(Xopt- Mstar,'fro')/normM
        
        SubgScad_matrank(test_iter,i) = rankX
        
        SubgScad_matrelerr(test_iter,i) = Subgrad_relerr
        
        SubgScad_mattime(test_iter,i) =  SubgScad_time


    end
      
    iPMM_averelerr(i)= mean(scadPAM_matrelerr(:,i))
    
    iPMM_averank(i)= mean(scadPAM_matrank(:,i))
    
    iPMM_avetime(i)= mean(scadPAM_mattime(:,i))


    SubgScad_averelerr(i)= mean(SubgScad_matrelerr(:,i))
    
    SubgScad_averank(i)= mean(SubgScad_matrank(:,i))
    
    SubgScad_avetime(i)= mean(SubgScad_mattime(:,i))
    

end

%% *************************************************************************
